using System;
using System.Windows.Forms.Design;

namespace CodeSmith.FileSystemEditors
{
	/// <summary>
	/// Overrides the default folder browser, starting browsing with "My Computer", adding a textbox in which the folder name can be typed (with a dropdown list matching feature).
	/// </summary>
	public class FolderNameEditor : System.Windows.Forms.Design.FolderNameEditor
	{
		public FolderNameEditor()
		{
		}
	
		protected override void InitializeDialog(FolderBrowser folderBrowser)
		{
			base.InitializeDialog (folderBrowser);

			folderBrowser.Description = "Select the destination folder for your output.";
			folderBrowser.StartLocation = FolderBrowserFolder.MyComputer;
			folderBrowser.Style = FolderBrowserStyles.ShowTextBox;
		}
	}
}
