using System;

namespace CodeSmith.FileSystemEditors
{
	/// <summary>
	/// Overrides the default filename editor that adds filters and allows the selection of files that do not exist, like the behavior of a File Save dialog.
	/// </summary>
	public class FileNameEditor : System.Windows.Forms.Design.FileNameEditor
	{
		public FileNameEditor()
		{
		}
	
		protected override void InitializeDialog(System.Windows.Forms.OpenFileDialog openFileDialog)
		{
			base.InitializeDialog(openFileDialog);

			openFileDialog.CheckFileExists = false;
			openFileDialog.ShowReadOnly = false;
			openFileDialog.Title = "Save Output As";
			openFileDialog.Filter = "All Files (*.*)|*.*|C# Source (*.cs)|*.cs|Visual Basic Source (*.vb)|*.vb|SQL Source (*.sql)|*.sql|HTML file (*.htm;*.html)|*.htm;*.html|Text files (*.txt)|*.txt";
		}
	}

	public class CSharpFileNameEditor : System.Windows.Forms.Design.FileNameEditor
	{
		public CSharpFileNameEditor()
		{
		}
	
		protected override void InitializeDialog(System.Windows.Forms.OpenFileDialog openFileDialog)
		{
			base.InitializeDialog(openFileDialog);

			openFileDialog.CheckFileExists = false;
			openFileDialog.ShowReadOnly = false;
			openFileDialog.Title = "Save Output As";
			openFileDialog.Filter = "C# Source (*.cs)|*.cs|All Files (*.*)|*.*";
			openFileDialog.DefaultExt = "cs";
		}
	}

	public class VBFileNameEditor : System.Windows.Forms.Design.FileNameEditor
	{
		public VBFileNameEditor()
		{
		}
	
		protected override void InitializeDialog(System.Windows.Forms.OpenFileDialog openFileDialog)
		{
			base.InitializeDialog(openFileDialog);

			openFileDialog.CheckFileExists = false;
			openFileDialog.ShowReadOnly = false;
			openFileDialog.Title = "Save Output As";
			openFileDialog.Filter = "Visual Basic Source (*.vb)|*.vb|All Files (*.*)|*.*";
			openFileDialog.DefaultExt = "vb";
		}
	}

	public class SQLFileNameEditor : System.Windows.Forms.Design.FileNameEditor
	{
		public SQLFileNameEditor()
		{
		}
	
		protected override void InitializeDialog(System.Windows.Forms.OpenFileDialog openFileDialog)
		{
			base.InitializeDialog(openFileDialog);

			openFileDialog.CheckFileExists = false;
			openFileDialog.ShowReadOnly = false;
			openFileDialog.Title = "Save Output As";
			openFileDialog.Filter = "SQL Source (*.sql)|*.sql|All Files (*.*)|*.*";
			openFileDialog.DefaultExt = "sql";
		}
	}

	public class HTMLFileNameEditor : System.Windows.Forms.Design.FileNameEditor
	{
		public HTMLFileNameEditor()
		{
		}
	
		protected override void InitializeDialog(System.Windows.Forms.OpenFileDialog openFileDialog)
		{
			base.InitializeDialog(openFileDialog);

			openFileDialog.CheckFileExists = false;
			openFileDialog.ShowReadOnly = false;
			openFileDialog.Title = "Save Output As";
			openFileDialog.Filter = "HTML file (*.htm;*.html)|*.htm;*.html|All Files (*.*)|*.*";
			openFileDialog.DefaultExt = "htm";
		}
	}

	public class TextFileNameEditor : System.Windows.Forms.Design.FileNameEditor
	{
		public TextFileNameEditor()
		{
		}
	
		protected override void InitializeDialog(System.Windows.Forms.OpenFileDialog openFileDialog)
		{
			base.InitializeDialog(openFileDialog);

			openFileDialog.CheckFileExists = false;
			openFileDialog.ShowReadOnly = false;
			openFileDialog.Title = "Save Output As";
			openFileDialog.Filter = "Text files (*.txt)|*.txt|All Files (*.*)|*.*";
			openFileDialog.DefaultExt = "txt";
		}
	}
}
